// ==============================================================================
// 📋 ระบบกระดานประกาศแต่ละแผนก (Bulletin Board)
// ไฟล์: backend/server.js
// คำอธิบาย: รวมโค้ด Backend API ทั้งหมดไว้ในไฟล์เดียว เพื่อให้ผู้เริ่มต้นอ่านและแก้ไขได้ง่าย
// ==============================================================================

// ------------------------------------------------------------------------------
// ส่วนที่ 1: นำเข้า Libraries และตั้งค่าพื้นฐาน
// ------------------------------------------------------------------------------
const express = require('express');   // เฟรมเวิร์กสำหรับสร้าง REST API
const cors = require('cors');         // อนุญาตให้ Frontend (localhost:5173) เรียกใช้ API ได้
const path = require('path');         // ช่วยจัดการเส้นทางไฟล์และโฟลเดอร์
const fs = require('fs');             // ช่วยอ่าน/เขียน/ลบไฟล์บนเครื่อง
const multer = require('multer');     // มิดเดิลแวร์สำหรับรับไฟล์อัปโหลด (รูปภาพ)
const { Pool } = require('pg');       // ไดรเวอร์เชื่อมต่อ PostgreSQL
require('dotenv').config();           // อ่านค่าจากไฟล์ .env

const app = express();
const PORT = process.env.PORT || 5000;

// ------------------------------------------------------------------------------
// ส่วนที่ 2: เชื่อมต่อฐานข้อมูล PostgreSQL
// ------------------------------------------------------------------------------
// ค่าเริ่มต้นจะดึงมาจากไฟล์ .env (สามารถเปลี่ยนรหัสผ่านใน .env ได้เลย)
const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: parseInt(process.env.PGPORT || '5432', 10),
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || '12345678',
  database: process.env.PGDATABASE || 'bulletin',
});

pool.query(`
  SELECT table_schema, table_name 
  FROM information_schema.tables 
  WHERE table_schema = 'public'
`)
  .then(res => {
    console.log("👉 Tables Node.js can see:", res.rows.map(r => r.table_name));
  })
  .catch(err => console.error("Error checking tables:", err));
  
// ฟังก์ชันลัดสำหรับส่งคำสั่ง SQL ไปรันในฐานข้อมูล
const query = (text, params) => pool.query(text, params);

// ------------------------------------------------------------------------------
// ส่วนที่ 3: ตั้งค่าโฟลเดอร์เก็บรูปภาพ และ Multer (File Upload)
// ------------------------------------------------------------------------------
const uploadDir = path.join(__dirname, 'uploads');
// ตรวจสอบ ถ้ายังไม่มีโฟลเดอร์ uploads ให้สร้างขึ้นมาอัตโนมัติ
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// กำหนดวิธีการตั้งชื่อไฟล์รูป เพื่อป้องกันชื่อไฟล์ซ้ำกัน
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname); // นามสกุลไฟล์ เช่น .png, .jpg
    const uniqueName = `post-${Date.now()}-${Math.round(Math.random() * 1e6)}${ext}`;
    cb(null, uniqueName);
  },
});

// กรองเฉพาะไฟล์ที่เป็นรูปภาพเท่านั้น
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('อนุญาตให้อัปโหลดเฉพาะไฟล์รูปภาพเท่านั้น!'), false);
  }
};

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // ขนาดสูงสุดไม่เกิน 10MB
  fileFilter: fileFilter,
});

// ------------------------------------------------------------------------------
// ส่วนที่ 4: Middleware พื้นฐาน
// ------------------------------------------------------------------------------
app.use(cors());                         // อนุญาต Cross-Origin
app.use(express.json());                 // แปลงข้อมูล Request Body แบบ JSON ให้อัตโนมัติ
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(uploadDir)); // ให้ Frontend เข้าถึงรูปได้ เช่น http://localhost:5000/uploads/xxx.png

// ทดสอบสถานะเซิร์ฟเวอร์และการเชื่อมต่อ Database
app.get('/api/health', async (req, res) => {
  try {
    const result = await query('SELECT NOW()');
    res.json({ status: 'ok', time: result.rows[0].now, message: 'Backend & PostgreSQL พร้อมใช้งาน' });
  } catch (err) {
    res.status(500).json({ status: 'error', error: err.message });
  }
});

// ==============================================================================
// ส่วนที่ 5: API สำหรับ Folder แผนก (Departments) - ตอบสนองข้อ 1 และ 2
// ==============================================================================

// 5.1 [GET] ดึงรายการแผนกทั้งหมด พร้อมนับจำนวน Category และ Post ข้างใน
app.get('/api/departments', async (req, res) => {
  try {
    const sql = `
      SELECT 
        d.id, 
        d.name, 
        d.description, 
        d.created_by_email, 
        d.created_at,
        COUNT(DISTINCT c.id)::int AS category_count,
        COUNT(DISTINCT p.id)::int AS post_count
      FROM departments d
      LEFT JOIN categories c ON c.department_id = d.id
      LEFT JOIN posts p ON p.category_id = c.id
      GROUP BY d.id
      ORDER BY d.id ASC;
    `;
    const result = await query(sql);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching departments:', err);
    res.status(500).json({ error: 'ไม่สามารถดึงข้อมูลแผนกได้' });
  }
});

// 5.2 [GET] ดึงข้อมูลแผนกเดี่ยวตาม ID
app.get('/api/departments/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query('SELECT * FROM departments WHERE id = $1', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบแผนกที่ระบุ' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'เกิดข้อผิดพลาดในการดึงข้อมูลแผนก' });
  }
});

// 5.3 [POST] สร้าง Folder แผนกใหม่ (ปุ่ม + ในหน้า Home)
app.post('/api/departments', async (req, res) => {
  try {
    const { name, description, created_by_email } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'กรุณาระบุชื่อแผนก' });
    }
    if (!created_by_email) {
      return res.status(400).json({ error: 'ไม่พบ Session อีเมลผู้สร้าง' });
    }

    const sql = `
      INSERT INTO departments (name, description, created_by_email)
      VALUES ($1, $2, $3)
      RETURNING *;
    `;
    const result = await query(sql, [name.trim(), description || '', created_by_email]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Error creating department:', err);
    res.status(500).json({ error: 'ไม่สามารถสร้างแผนกได้' });
  }
});

// 5.4 [DELETE] ลบ Folder แผนก
app.delete('/api/departments/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query('DELETE FROM departments WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบแผนกที่ต้องการลบ' });
    }
    res.json({ message: 'ลบแผนกสำเร็จ', deleted: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'ไม่สามารถลบแผนกได้' });
  }
});

// ==============================================================================
// ส่วนที่ 6: API สำหรับ Folder หมวดหมู่ (Categories) - ตอบสนองข้อ 3
// ==============================================================================

// 6.1 [GET] ดึงหมวดหมู่ทั้งหมดในแผนก พร้อมนับจำนวนโพสต์
app.get('/api/departments/:departmentId/categories', async (req, res) => {
  try {
    const { departmentId } = req.params;
    const sql = `
      SELECT 
        c.id, 
        c.department_id, 
        c.name, 
        c.description, 
        c.created_by_email, 
        c.created_at,
        COUNT(p.id)::int AS post_count
      FROM categories c
      LEFT JOIN posts p ON p.category_id = c.id
      WHERE c.department_id = $1
      GROUP BY c.id
      ORDER BY c.id ASC;
    `;
    const result = await query(sql, [departmentId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'ไม่สามารถดึงหมวดหมู่ได้' });
  }
});

// 6.2 [GET] ดึงข้อมูลหมวดหมู่เดี่ยว
app.get('/api/categories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const sql = `
      SELECT c.*, d.name AS department_name
      FROM categories c
      JOIN departments d ON d.id = c.department_id
      WHERE c.id = $1;
    `;
    const result = await query(sql, [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบหมวดหมู่นี้' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'ไม่สามารถดึงข้อมูลหมวดหมู่ได้' });
  }
});

// 6.3 [POST] สร้าง Folder หมวดหมู่ใหม่ในแผนก
app.post('/api/categories', async (req, res) => {
  try {
    const { department_id, name, description, created_by_email } = req.body;
    if (!department_id) {
      return res.status(400).json({ error: 'กรุณาระบุรหัสแผนก' });
    }
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'กรุณากรอกชื่อหมวดหมู่' });
    }
    if (!created_by_email) {
      return res.status(400).json({ error: 'ไม่พบ Session อีเมลผู้สร้าง' });
    }

    const sql = `
      INSERT INTO categories (department_id, name, description, created_by_email)
      VALUES ($1, $2, $3, $4)
      RETURNING *;
    `;
    const result = await query(sql, [department_id, name.trim(), description || '', created_by_email]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'ไม่สามารถสร้างหมวดหมู่ได้' });
  }
});

// 6.4 [DELETE] ลบ Folder หมวดหมู่
app.delete('/api/categories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query('DELETE FROM categories WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบหมวดหมู่ที่ต้องการลบ' });
    }
    res.json({ message: 'ลบหมวดหมู่สำเร็จ' });
  } catch (err) {
    res.status(500).json({ error: 'ไม่สามารถลบหมวดหมู่ได้' });
  }
});

// ==============================================================================
// ส่วนที่ 7: API สำหรับโพสต์ประกาศ (Posts) - ตอบสนองข้อ 3b และ ข้อ 4
// ==============================================================================

// 7.1 [GET] ดึงโพสต์ประกาศทั้งหมดในหมวดหมู่ (เรียงจากใหม่สุดไปเก่าสุด)
app.get('/api/categories/:categoryId/posts', async (req, res) => {
  try {
    const { categoryId } = req.params;
    const sql = 'SELECT * FROM posts WHERE category_id = $1 ORDER BY created_at DESC;';
    const result = await query(sql, [categoryId]);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'ไม่สามารถดึงโพสต์ประกาศได้' });
  }
});

// 7.2 [POST] สร้างโพสต์ประกาศใหม่ (แนบข้อความ และรูปภาพได้)
app.post('/api/posts', upload.single('image'), async (req, res) => {
  try {
    const { category_id, title, content, created_by_email } = req.body;

    if (!category_id) return res.status(400).json({ error: 'กรุณาระบุหมวดหมู่' });
    if (!title || !title.trim()) return res.status(400).json({ error: 'กรุณากรอกหัวข้อประกาศ' });
    if (!content || !content.trim()) return res.status(400).json({ error: 'กรุณากรอกเนื้อหาข้อความ' });
    if (!created_by_email) return res.status(400).json({ error: 'ไม่พบข้อมูลผู้สร้าง (Session)' });

    // ถ้ามีการอัปโหลดไฟล์รูป ให้ตั้ง path เป็น /uploads/ชื่อไฟล์
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    const sql = `
      INSERT INTO posts (category_id, title, content, image_url, created_by_email)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *;
    `;
    const result = await query(sql, [category_id, title.trim(), content.trim(), imageUrl, created_by_email]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Error creating post:', err);
    res.status(500).json({ error: 'ไม่สามารถสร้างโพสต์ได้' });
  }
});

// 7.3 [PUT] แก้ไขโพสต์ประกาศ (**สำคัญ: เฉพาะผู้สร้างเท่านั้น - ข้อ 4**)
app.put('/api/posts/:id', upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    const { title, content, remove_image } = req.body;
    // รับอีเมลผู้ส่งเพื่อเช็คสิทธิ์ (จาก header หรือ body)
    const userEmail = req.body.user_email || req.headers['x-user-email'];

    if (!userEmail) {
      return res.status(401).json({ error: 'กรุณาระบุอีเมลเพื่อยืนยันตัวตน' });
    }

    // ขั้นที่ 1: ดึงโพสต์เดิมขึ้นมาตรวจ
    const checkResult = await query('SELECT * FROM posts WHERE id = $1', [id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบโพสต์ที่ต้องการแก้ไข' });
    }

    const currentPost = checkResult.rows[0];

    // ขั้นที่ 2: ตรวจสิทธิ์ว่าอีเมลตรงกับผู้สร้างโพสต์หรือไม่ (Req 4)
    if (currentPost.created_by_email !== userEmail) {
      return res.status(403).json({
        error: 'คุณไม่มีสิทธิ์แก้ไขโพสต์นี้ เนื่องจากคุณไม่ใช่ผู้สร้างโพสต์!',
      });
    }

    // ขั้นที่ 3: จัดการรูปภาพ (ถ้ามีอัปโหลดรูปใหม่ หรือเลือกลบรูป)
    let finalImageUrl = currentPost.image_url;
    if (req.file) {
      finalImageUrl = `/uploads/${req.file.filename}`;
    } else if (remove_image === 'true' || remove_image === true) {
      finalImageUrl = null;
    }

    const newTitle = title !== undefined ? title.trim() : currentPost.title;
    const newContent = content !== undefined ? content.trim() : currentPost.content;

    const sql = `
      UPDATE posts 
      SET title = $1, content = $2, image_url = $3, updated_at = CURRENT_TIMESTAMP
      WHERE id = $4
      RETURNING *;
    `;
    const result = await query(sql, [newTitle, newContent, finalImageUrl, id]);
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error updating post:', err);
    res.status(500).json({ error: 'ไม่สามารถแก้ไขโพสต์ได้' });
  }
});

// 7.4 [DELETE] ลบโพสต์ประกาศ (**สำคัญ: เฉพาะผู้สร้างเท่านั้น - ข้อ 4**)
app.delete('/api/posts/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const userEmail = req.query.user_email || req.headers['x-user-email'];

    if (!userEmail) {
      return res.status(401).json({ error: 'กรุณาระบุอีเมลเพื่อยืนยันตัวตนก่อนลบ' });
    }

    // ตรวจสอบโพสต์เดิม
    const checkResult = await query('SELECT * FROM posts WHERE id = $1', [id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'ไม่พบโพสต์ที่ต้องการลบ' });
    }

    const currentPost = checkResult.rows[0];

    // ตรวจสิทธิ์เฉพาะผู้สร้าง (Req 4)
    if (currentPost.created_by_email !== userEmail) {
      return res.status(403).json({
        error: 'คุณไม่มีสิทธิ์ลบโพสต์นี้ เนื่องจากคุณไม่ใช่ผู้สร้างโพสต์!',
      });
    }

    // ลบไฟล์รูปออกจากโฟลเดอร์ uploads (ถ้ามี) เพื่อประหยัดพื้นที่ฮาร์ดดิสก์
    if (currentPost.image_url && currentPost.image_url.startsWith('/uploads/')) {
      const fileName = path.basename(currentPost.image_url);
      const filePath = path.join(uploadDir, fileName);
      if (fs.existsSync(filePath)) {
        fs.unlink(filePath, () => {});
      }
    }

    // ลบโพสต์ออกจากฐานข้อมูล
    await query('DELETE FROM posts WHERE id = $1', [id]);
    res.json({ message: 'ลบโพสต์สำเร็จเรียบร้อย', id: Number(id) });
  } catch (err) {
    console.error('Error deleting post:', err);
    res.status(500).json({ error: 'ไม่สามารถลบโพสต์ได้' });
  }
});

// ------------------------------------------------------------------------------
// ส่วนที่ 8: คำสั่งเปิดรันเซิร์ฟเวอร์
// ------------------------------------------------------------------------------
app.listen(PORT, () => {
  console.log(`=================================================`);
  console.log(`🚀 Bulletin API Server ทำงานที่พอร์ต: ${PORT}`);
  console.log(`📁 รูปภาพอัปโหลดจัดเก็บที่: ${uploadDir}`);
  console.log(`=================================================`);
});

