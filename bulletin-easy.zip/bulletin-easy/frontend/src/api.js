// ==============================================================================
// 📋 ฟังก์ชันเชื่อมต่อ Backend API (frontend/src/api.js)
// คำอธิบาย: รวมคำสั่ง fetch ไว้ที่เดียว เพื่อให้เด็กใหม่แก้ไข URL หรือฟังก์ชันได้ง่าย
// ==============================================================================

// URL ของเซิร์ฟเวอร์ Backend
export const API_BASE_URL = 'http://localhost:5000';

// ฟังก์ชันกลางสำหรับส่ง Request
async function request(endpoint, options = {}) {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const errorMsg = data?.error || `เกิดข้อผิดพลาด (${response.status})`;
    throw new Error(errorMsg);
  }
  return data;
}

// ------------------------------------------------------------------------------
// 1. API สำหรับแผนก (Departments)
// ------------------------------------------------------------------------------

// ดึงรายการแผนกทั้งหมด
export const getDepartments = () => request('/api/departments');

// ดึงข้อมูลแผนกเดี่ยว
export const getDepartment = (id) => request(`/api/departments/${id}`);

// สร้าง Folder แผนกใหม่
export const createDepartment = (name, description, email) =>
  request('/api/departments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description, created_by_email: email }),
  });

// ลบ Folder แผนก
export const deleteDepartment = (id) =>
  request(`/api/departments/${id}`, { method: 'DELETE' });

// ------------------------------------------------------------------------------
// 2. API สำหรับหมวดหมู่ย่อย (Categories)
// ------------------------------------------------------------------------------

// ดึงหมวดหมู่ทั้งหมดในแผนก
export const getCategories = (departmentId) =>
  request(`/api/departments/${departmentId}/categories`);

// ดึงข้อมูลหมวดหมู่เดี่ยว
export const getCategory = (id) => request(`/api/categories/${id}`);

// สร้าง Folder หมวดหมู่ใหม่
export const createCategory = (departmentId, name, description, email) =>
  request('/api/categories', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      department_id: departmentId,
      name,
      description,
      created_by_email: email,
    }),
  });

// ลบ Folder หมวดหมู่
export const deleteCategory = (id) =>
  request(`/api/categories/${id}`, { method: 'DELETE' });

// ------------------------------------------------------------------------------
// 3. API สำหรับโพสต์ประกาศ (Posts)
// ------------------------------------------------------------------------------

// ดึงโพสต์ทั้งหมดในหมวดหมู่
export const getPosts = (categoryId) =>
  request(`/api/categories/${categoryId}/posts`);

// สร้างโพสต์ประกาศใหม่ (รับ FormData เพราะมีไฟล์รูปภาพ)
export const createPost = (formData) =>
  request('/api/posts', {
    method: 'POST',
    body: formData, // Browser จะตั้ง multipart/form-data boundary ให้อัตโนมัติ
  });

// แก้ไขโพสต์ (ส่ง user_email ไปเช็คสิทธิ์ผู้สร้าง)
export const updatePost = (postId, formData, userEmail) =>
  request(`/api/posts/${postId}`, {
    method: 'PUT',
    headers: { 'x-user-email': userEmail },
    body: formData,
  });

// ลบโพสต์ (ส่ง user_email ไปเช็คสิทธิ์ผู้สร้าง)
export const deletePost = (postId, userEmail) =>
  request(`/api/posts/${postId}`, {
    method: 'DELETE',
    headers: { 'x-user-email': userEmail },
  });

// ------------------------------------------------------------------------------
// ฟังก์ชันช่วยจัดรูปแบบที่อยู่รูปภาพ (Image URL Helper)
// ------------------------------------------------------------------------------
export const getImageUrl = (imagePath) => {
  if (!imagePath) return null;
  if (imagePath.startsWith('http')) return imagePath;
  return `${API_BASE_URL}${imagePath}`;
};

