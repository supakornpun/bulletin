function doGet(e) {
  var userEmail = Session.getActiveUser().getEmail();
  var allowedDomain = "@minebea.co.th"; 
  
  if (userEmail) {
    if (userEmail.endsWith(allowedDomain)) {
      var redirectUrl = "http://localhost:5174/success?email=" + encodeURIComponent(userEmail);
      
      var html = '<div style="text-align:center; font-family:sans-serif; margin-top:100px;">' +
                 '<h2>ยืนยันตัวตนสำเร็จ ✅</h2>' +
                 '<p style="color:#666; margin-bottom: 30px;">คุณเข้าสู่ระบบด้วย: <strong>' + userEmail + '</strong></p>' +
                 
                 // ให้ผู้ใช้กดปุ่มนี้เพื่อผ่านระบบความปลอดภัยของเบราว์เซอร์
                 '<a href="' + redirectUrl + '" target="_top" style="padding:10px 20px; background:#28a745; color:white; text-decoration:none; border-radius:4px; font-size:16px; font-weight:bold; box-shadow: 0 4px 6px rgba(0,0,0,0.1); cursor:pointer;">' +
                 'Done' +
                 '</a>' +
                 '</div>';
                 
      return HtmlService.createHtmlOutput(html);
    } else {
      var errorHtml = '<div style="text-align:center; font-family:sans-serif; margin-top:50px; color:red;">' +
                      '<h2>ปฏิเสธการเข้าถึง ❌</h2>' +
                      '<p>กรุณาใช้อีเมลองค์กรในการเข้าสู่ระบบเท่านั้น</p>' +
                      '</div>';
      return HtmlService.createHtmlOutput(errorHtml);
    }
  } 
}