import React from 'react';
import { useNavigate } from 'react-router-dom';

function Navbar({ userEmail }) {
  const navigate = useNavigate();

  // ฟังก์ชันออกจากระบบ
  const handleLogout = () => {
    if (window.confirm('คุณต้องการออกจากระบบใช่หรือไม่?')) {
      localStorage.removeItem('user_session'); // ล้างข้อมูล session
      navigate('/login');                       // เด้งกลับไปหน้า login
    }
  };

  return (
    <nav className="navbar">
      {/* โลโก้และชื่อระบบ คลิกแล้วกลับหน้าแรก */}
      <div className="brand" onClick={() => navigate('/home')}>
        <div className="brand-icon">📋</div>
        <div className="brand-text">
          <h2>Bulletin Board</h2>
          <p>ระบบกระดานประกาศองค์กร</p>
        </div>
      </div>

      {/* ส่วนแสดงอีเมลผู้ใช้งาน และปุ่มออกจากระบบ */}
      <div className="navbar-right">
        {userEmail && (
          <div className="user-badge">
            <span className="status-dot"></span>
            <span>{userEmail}</span>
          </div>
        )}

        <button onClick={handleLogout} className="btn btn-danger" style={{ padding: '7px 14px', fontSize: '13px' }}>
          Sign Out
        </button>
      </div>
    </nav>
  );
}

export default Navbar;

