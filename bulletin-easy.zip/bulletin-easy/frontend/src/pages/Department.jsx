import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { getDepartment, getCategories, createCategory, deleteCategory } from '../api';

function Department() {
  const { id } = useParams(); // รหัสแผนกจาก URL เช่น /department/1
  const navigate = useNavigate();

  const [department, setDepartment] = useState(null);
  const [categories, setCategories] = useState([]);
  const [userEmail, setUserEmail] = useState('');
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [catNameInput, setCatNameInput] = useState('');
  const [catDescInput, setCatDescInput] = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [deptData, catData] = await Promise.all([
        getDepartment(id),
        getCategories(id),
      ]);
      setDepartment(deptData);
      setCategories(catData || []);
    } catch (err) {
      console.warn('โหลดข้อมูลแผนกไม่สำเร็จ (ใช้ข้อมูลจำลอง):', err);
      setDepartment({ id: Number(id), name: `แผนก #${id}`, description: 'Folder แผนก' });
      setCategories([
        { id: 101, name: 'สวัสดิการและการเบิกจ่าย', description: 'ข้อมูลประกันสุขภาพและค่ารักษา', post_count: 3 },
        { id: 102, name: 'การอบรมและกิจกรรม', description: 'ตารางฝึกอบรมพนักงาน', post_count: 1 },
      ]);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    const sessionEmail = localStorage.getItem('user_session');
    if (!sessionEmail) {
      navigate('/login');
      return;
    }
    setUserEmail(sessionEmail);
    loadData();
  }, [navigate, loadData]);

  // ฟังก์ชันสร้าง Folder Category ใหม่ (ข้อ 3)
  const handleCreateCategory = async (e) => {
    e.preventDefault();
    if (!catNameInput.trim()) return alert('กรุณากรอกชื่อหมวดหมู่');

    try {
      const created = await createCategory(id, catNameInput.trim(), catDescInput.trim(), userEmail);
      setCategories([...categories, { ...created, post_count: 0 }]);
      setIsModalOpen(false);
      setCatNameInput('');
      setCatDescInput('');
    } catch (err) {
      alert('สร้างหมวดหมู่ไม่สำเร็จ: ' + err.message);
    }
  };

  // ฟังก์ชันลบ Category
  const handleDeleteCategory = async (e, catId, catName) => {
    e.stopPropagation();
    if (window.confirm(`คุณต้องการลบ Folder หมวดหมู่ "${catName}" ใช่หรือไม่?`)) {
      try {
        await deleteCategory(catId);
        setCategories(categories.filter((c) => c.id !== catId));
      } catch (err) {
        alert('ลบหมวดหมู่ไม่สำเร็จ: ' + err.message);
      }
    }
  };

  return (
    <div>
      <Navbar userEmail={userEmail} />

      <main className="container">
        {/* แถบนำทาง Breadcrumb */}
        <div className="breadcrumb">
          <Link to="/home">🏠 Home</Link>
          <span>/</span>
          <span style={{ fontWeight: 600, color: '#0f172a' }}>{department?.name || 'กำลังโหลด...'}</span>
        </div>

        {/* ส่วนหัวแผนก และปุ่มสร้าง Folder Category (ข้อ 3) */}
        <div className="page-header">
          <div className="page-title">
            <h1>{department?.name || '...'}</h1>
            <p>{department?.description || 'เลือกหรือสร้างหมวดหมู่ย่อยสำหรับจัดระเบียบประกาศ'}</p>
          </div>

          {/* ปุ่มสร้าง Folder Category ย่อย (ข้อ 3) */}
          <button onClick={() => setIsModalOpen(true)} className="btn btn-primary">
            <span style={{ fontSize: '18px' }}>+</span>
            <span>Create Category</span>
          </button>
        </div>

        {/* แสดงรายการ Folder Category */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: '50px 0', color: '#64748b' }}>⏳ กำลังโหลดหมวดหมู่...</div>
        ) : categories.length === 0 ? (
          <div className="empty-box">
            <div className="empty-icon">📂</div>
            <h3>No have Category Folders</h3>
            <p>Press button "+ Create Category" to start organizing announcements</p>
            <button onClick={() => setIsModalOpen(true)} className="btn btn-primary">
              + Create Category
            </button>
          </div>
        ) : (
          <div className="folder-grid">
            {categories.map((cat) => (
              <div
                key={cat.id}
                className="folder-card"
                onClick={() => navigate(`/category/${cat.id}`)} // คลิกลึกเข้าไปในห้องประกาศ
              >
                <div>
                  <div className="card-top">
                    <span className="card-folder-icon">📂</span>
                    <button
                      onClick={(e) => handleDeleteCategory(e, cat.id, cat.name)}
                      className="btn-delete-card"
                      title="ลบหมวดหมู่นี้"
                    >
                      🗑️
                    </button>
                  </div>
                  <h3 className="card-title">{cat.name}</h3>
                  <p className="card-desc">{cat.description || 'No Description'}</p>
                </div>

                <div className="card-footer">
                  <span>📢 {cat.post_count || 0} ประกาศ</span>
                  <span style={{ color: '#2563eb', fontWeight: 'bold' }}>Entry Announcement Room →</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal สำหรับสร้าง Folder Category ใหม่ */}
        {isModalOpen && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h3>📂 Create Category</h3>
                <button onClick={() => setIsModalOpen(false)} className="btn-close-modal">✕</button>
              </div>

              <form onSubmit={handleCreateCategory}>
                <div className="form-group">
                  <label>Category Name<span style={{ color: 'red' }}>*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="เช่น ประกาศสวัสดิการ, อบรมประจำเดือน"
                    className="form-control"
                    value={catNameInput}
                    onChange={(e) => setCatNameInput(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label>Description (if any)</label>
                  <textarea
                    rows={3}
                    placeholder="Detail of Category..."
                    className="form-control"
                    value={catDescInput}
                    onChange={(e) => setDescInput(e.target.value)}
                  />
                </div>

                <div className="modal-actions">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="btn btn-secondary">
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Category
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default Department;

