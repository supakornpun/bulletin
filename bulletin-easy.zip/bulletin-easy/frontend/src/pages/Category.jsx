import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { getCategory, getPosts, createPost, updatePost, deletePost, getImageUrl } from '../api';

function Category() {
  const { id } = useParams(); // รหัสหมวดหมู่จาก URL เช่น /category/1
  const navigate = useNavigate();

  // ข้อมูลหมวดหมู่ และรายการโพสต์
  const [category, setCategory] = useState(null);
  const [posts, setPosts] = useState([]);
  const [userEmail, setUserEmail] = useState('');
  const [loading, setLoading] = useState(true);

  // State สำหรับ Modal สร้างโพสต์ใหม่
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // State สำหรับ Modal แก้ไขโพสต์ (ข้อ 4)
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [editFile, setEditFile] = useState(null);
  const [editPreviewUrl, setEditPreviewUrl] = useState('');
  const [removeOldImage, setRemoveOldImage] = useState(false);

  // State สำหรับดูรูปภาพขนาดใหญ่ (Lightbox)
  const [zoomImage, setZoomImage] = useState(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [catData, postsData] = await Promise.all([
        getCategory(id),
        getPosts(id),
      ]);
      setCategory(catData);
      setPosts(postsData || []);
    } catch (err) {
      console.warn('โหลดข้อมูลไม่สำเร็จ (ใช้ข้อมูลจำลอง):', err);
      setCategory({
        id: Number(id),
        department_id: 1,
        department_name: 'ฝ่ายทรัพยากรบุคคล (HR)',
        name: 'สวัสดิการและการเบิกจ่าย',
        description: 'รวมประกาศสิทธิประโยชน์พนักงาน',
      });
      setPosts([
        {
          id: 201,
          category_id: Number(id),
          title: 'สิทธิประโยชน์ประกันสุขภาพกลุ่ม ประจำปี 2026',
          content: 'ขอแจ้งรายละเอียดการใช้สิทธิ์ OPD/IPD สำหรับพนักงานทุกระดับ ติดต่อสอบถามได้ที่เคาน์เตอร์ HR ชั้น 2',
          image_url: null,
          created_by_email: 'admin.hr@minebea.co.th',
          created_at: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    const sessionEmail = localStorage.getItem('user_session');
    if (!sessionEmail) {
      navigate('/login');
      return;
    }
    setUserEmail(sessionEmail);
    loadData();
  }, [navigate, loadData]);

  // ฟังก์ชันเลือกไฟล์รูปภาพ (สร้างโพสต์)
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) return alert('Please select a valid image file.');
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file)); // สร้าง URL จำลองเพื่อแสดงรูปตัวอย่าง
    }
  };

  // 1. ส่งข้อมูลสร้างโพสต์ใหม่ (ข้อ 3b)
  const handleCreatePost = async (e) => {
    e.preventDefault();
    if (!postTitle.trim() || !postContent.trim()) {
      return alert('Please fill in both the title and content fields.');
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('category_id', id);
      formData.append('title', postTitle.trim());
      formData.append('content', postContent.trim());
      formData.append('created_by_email', userEmail);
      if (selectedFile) {
        formData.append('image', selectedFile);
      }

      const created = await createPost(formData);
      setPosts([created, ...posts]); // นำโพสต์ใหม่ขึ้นบนสุด
      setIsCreateOpen(false);
      setPostTitle('');
      setPostContent('');
      setSelectedFile(null);
      setPreviewUrl('');
    } catch (err) {
      alert('Create Post Failed: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // 2. เปิดหน้าต่างแก้ไขโพสต์ (ข้อ 4: ตรวจสอบสิทธิ์ผู้สร้าง)
  const handleOpenEdit = (post) => {
    if (post.created_by_email !== userEmail) {
      return alert('You do not have permission to edit this post because you are not the author!');
    }
    setEditingPost(post);
    setEditTitle(post.title);
    setEditContent(post.content);
    setEditFile(null);
    setEditPreviewUrl('');
    setRemoveOldImage(false);
    setIsEditOpen(true);
  };

  // บันทึกการแก้ไขโพสต์ (ข้อ 4)
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!editTitle.trim() || !editContent.trim()) {
      return alert('Please fill in both the title and content fields.');
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('title', editTitle.trim());
      formData.append('content', editContent.trim());
      formData.append('user_email', userEmail);
      if (editFile) {
        formData.append('image', editFile);
      } else if (removeOldImage) {
        formData.append('remove_image', 'true');
      }

      const updated = await updatePost(editingPost.id, formData, userEmail);
      setPosts(posts.map((p) => (p.id === editingPost.id ? updated : p)));
      setIsEditOpen(false);
    } catch (err) {
      alert('Edit Post Failed: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // 3. ลบโพสต์ประกาศ (ข้อ 4: ตรวจสอบสิทธิ์ผู้สร้าง)
  const handleDeletePost = async (post) => {
    if (post.created_by_email !== userEmail) {
      return alert('You do not have permission to delete this post because you are not the author!');
    }

    if (window.confirm(`You want to delete the post "${post.title}" ?`)) {
      try {
        await deletePost(post.id, userEmail);
        setPosts(posts.filter((p) => p.id !== post.id));
      } catch (err) {
        alert('Delete Post Failed: ' + err.message);
      }
    }
  };

  // ฟังก์ชันแปลงรูปแบบวันที่ให้อ่านง่าย
  const formatDate = (isoString) => {
    if (!isoString) return '';
    const d = new Date(isoString);
    return d.toLocaleDateString('th-TH', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div>
      <Navbar userEmail={userEmail} />

      <main className="container">
        {/* แถบนำทาง Breadcrumb */}
        <div className="breadcrumb">
          <Link to="/home">🏠 Home</Link>
          <span>/</span>
          {category?.department_id && (
            <>
              <Link to={`/department/${category.department_id}`}>
                {category?.department_name || `Department #${category.department_id}`}
              </Link>
              <span>/</span>
            </>
          )}
          <span style={{ fontWeight: 600, color: '#0f172a' }}>{category?.name || 'Announcement Room'}</span>
        </div>

        {/* ส่วนหัวห้องประกาศ และปุ่มสร้างโพสต์ใหม่ (ข้อ 3b) */}
        <div className="page-header">
          <div className="page-title">
            <h1>{category?.name || '...'}</h1>
            <p>{category?.description || 'List of announcements and important documents in this category'}</p>
          </div>

          {/* ปุ่มสร้างโพสต์ประกาศใหม่ (ข้อ 3b) */}
          <button onClick={() => setIsCreateOpen(true)} className="btn btn-success">
            <span style={{ fontSize: '18px' }}>+</span>
            <span>Create New Announcement</span>
          </button>
        </div>

        {/* รายการโพสต์ประกาศ */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: '50px 0', color: '#64748b' }}>⏳ กำลังโหลดโพสต์...</div>
        ) : posts.length === 0 ? (
          <div className="empty-box">
            <div className="empty-icon">📝</div>
            <h3>No have Announcement</h3>
            <p>Press button "+ Create Announcement" for first announcement</p>
            <button onClick={() => setIsCreateOpen(true)} className="btn btn-success">
              + Create Announcement
            </button>
          </div>
        ) : (
          <div className="post-list">
            {posts.map((post) => {
              // ตรวจสอบว่าผู้ล็อกอินปัจจุบันตรงกับผู้สร้างโพสต์นี้หรือไม่ (ข้อ 4)
              const isCreator = userEmail && post.created_by_email === userEmail;
              const fullImageUrl = getImageUrl(post.image_url);

              return (
                <article key={post.id} className="post-card">
                  {/* แถบข้อมูลผู้สร้าง และปุ่ม Edit / Delete (ข้อ 4) */}
                  <div className="post-card-header">
                    <div className="post-author-box">
                      <div className="author-avatar">
                        {post.created_by_email?.charAt(0).toUpperCase() || 'U'}
                      </div>
                      <div>
                        <div>
                          <span className="author-email">{post.created_by_email}</span>
                          {isCreator && <span className="author-badge">You are author</span>}
                        </div>
                        <span className="post-date">เผยแพร่เมื่อ: {formatDate(post.created_at)}</span>
                      </div>
                    </div>

                    {/* ปุ่ม EDIT และ DELETE จะแสดงเฉพาะผู้สร้างโพสต์เท่านั้น (ข้อ 4) */}
                    {isCreator ? (
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button
                          onClick={() => handleOpenEdit(post)}
                          className="btn btn-secondary"
                          style={{ padding: '6px 12px', fontSize: '12px' }}
                        >
                          ✏️ แก้ไข
                        </button>
                        <button
                          onClick={() => handleDeletePost(post)}
                          className="btn btn-danger"
                          style={{ padding: '6px 12px', fontSize: '12px' }}
                        >
                          🗑️ ลบ
                        </button>
                      </div>
                    ) : (
                      <span style={{ fontSize: '12px', color: '#94a3b8' }}>🔒 แก้ไข/ลบได้เฉพาะผู้สร้าง</span>
                    )}
                  </div>

                  {/* หัวข้อโพสต์ประกาศ */}
                  <h2 className="post-card-title">{post.title}</h2>

                  {/* เนื้อหาข้อความประกาศ (ข้อ 3b) */}
                  <p className="post-card-content">{post.content}</p>

                  {/* รูปภาพแนบ (ข้อ 3b) */}
                  {fullImageUrl && (
                    <div style={{ marginTop: '12px' }}>
                      <img
                        src={fullImageUrl}
                        alt={post.title}
                        className="post-card-img"
                        onClick={() => setZoomImage(fullImageUrl)}
                        title="คลิกเพื่อดูรูปภาพขนาดใหญ่"
                      />
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}

        {/* Modal สำหรับสร้างโพสต์ใหม่ (ข้อ 3b) */}
        {isCreateOpen && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h3>✍️ Create New Announcement</h3>
                <button onClick={() => setIsCreateOpen(false)} className="btn-close-modal">✕</button>
              </div>

              <form onSubmit={handleCreatePost}>
                <div className="form-group">
                  <label>Title Name <span style={{ color: 'red' }}>*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="eg,. Trainning Course 2026"
                    className="form-control"
                    value={postTitle}
                    onChange={(e) => setPostTitle(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label>Detail <span style={{ color: 'red' }}>*</span></label>
                  <textarea
                    rows={5}
                    required
                    placeholder="Announcement Detail..."
                    className="form-control"
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label>Upload Picture (if any)</label>
                  <input type="file" accept="image/*" onChange={handleFileChange} />
                  {previewUrl && (
                    <div style={{ marginTop: '10px' }}>
                      <img src={previewUrl} alt="Preview" style={{ maxHeight: '140px', borderRadius: '8px' }} />
                    </div>
                  )}
                </div>

                <div className="modal-actions">
                  <button type="button" onClick={() => setIsCreateOpen(false)} className="btn btn-secondary">
                    ยกเลิก
                  </button>
                  <button type="submit" disabled={submitting} className="btn btn-success">
                    {submitting ? 'Saving...' : 'Post'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal สำหรับแก้ไขโพสต์ (ข้อ 4) */}
        {isEditOpen && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h3>✏️ แก้ไขโพสต์ประกาศ</h3>
                <button onClick={() => setIsEditOpen(false)} className="btn-close-modal">✕</button>
              </div>

              <form onSubmit={handleEditSubmit}>
                <div className="form-group">
                  <label>หัวข้อประกาศ</label>
                  <input
                    type="text"
                    required
                    className="form-control"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label>เนื้อหาข้อความ</label>
                  <textarea
                    rows={5}
                    required
                    className="form-control"
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label>รูปภาพแนบ</label>
                  {editingPost?.image_url && !removeOldImage && !editPreviewUrl && (
                    <div style={{ marginBottom: '8px' }}>
                      <p style={{ fontSize: '12px', color: '#64748b' }}>รูปภาพปัจจุบัน:</p>
                      <img src={getImageUrl(editingPost.image_url)} alt="Current" style={{ maxHeight: '100px', borderRadius: '6px' }} />
                      <button
                        type="button"
                        onClick={() => setRemoveOldImage(true)}
                        style={{ display: 'block', color: 'red', border: 'none', background: 'none', fontSize: '12px', cursor: 'pointer', marginTop: '4px' }}
                      >
                        🗑️ ลบรูปนี้ออก
                      </button>
                    </div>
                  )}

                  {editPreviewUrl && (
                    <div style={{ marginBottom: '8px' }}>
                      <p style={{ fontSize: '12px', color: 'green' }}>รูปภาพใหม่:</p>
                      <img src={editPreviewUrl} alt="New" style={{ maxHeight: '100px', borderRadius: '6px' }} />
                    </div>
                  )}

                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files[0];
                      if (file) {
                        setEditFile(file);
                        setEditPreviewUrl(URL.createObjectURL(file));
                        setRemoveOldImage(false);
                      }
                    }}
                  />
                </div>

                <div className="modal-actions">
                  <button type="button" onClick={() => setIsEditOpen(false)} className="btn btn-secondary">
                    ยกเลิก
                  </button>
                  <button type="submit" disabled={submitting} className="btn btn-primary">
                    {submitting ? 'Saving...' : 'Save Edit'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Lightbox ดูรูปขยายใหญ่ */}
        {zoomImage && (
          <div
            onClick={() => setZoomImage(null)}
            style={{
              position: 'fixed',
              inset: 0,
              backgroundColor: 'rgba(0,0,0,0.85)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              zIndex: 2000,
              padding: '20px',
              cursor: 'zoom-out',
            }}
          >
            <img src={zoomImage} alt="Zoom" style={{ maxWidth: '90vw', maxHeight: '90vh', objectFit: 'contain', borderRadius: '8px' }} />
          </div>
        )}
      </main>
    </div>
  );
}

export default Category;

