import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { getDepartments, createDepartment, deleteDepartment } from '../api';

function Home() {
  const navigate = useNavigate();

  // State ต่างๆ ที่ใช้ในหน้านี้
  const [departments, setDepartments] = useState([]);      // รายการแผนกทั้งหมด
  const [userEmail, setUserEmail] = useState('');            // อีเมลของผู้ใช้ปัจจุบัน
  const [loading, setLoading] = useState(true);              // สถานะกำลังโหลดข้อมูล
  const [isModalOpen, setIsModalOpen] = useState(false);     // เปิด/ปิด Modal สร้างแผนก
  const [nameInput, setNameInput] = useState('');            // ข้อความชื่อแผนกในฟอร์ม
  const [descInput, setDescInput] = useState('');            // ข้อความคำอธิบายในฟอร์ม

  useEffect(() => {
    // ขั้นตอนที่ 1: ตรวจสอบ Session จาก localStorage (ข้อ 5)
    const sessionEmail = localStorage.getItem('user_session');
    if (!sessionEmail) {
      navigate('/login'); // ถ้ายังไม่ล็อกอิน ให้กลับไปหน้า Login
      return;
    }
    setUserEmail(sessionEmail);

    // ขั้นตอนที่ 2: ดึงข้อมูลแผนกจาก Backend
    loadDepartments();
  }, [navigate]);

  // ฟังก์ชันโหลดข้อมูลแผนก
  const loadDepartments = async () => {
    setLoading(true);
    try {
      const data = await getDepartments();
      setDepartments(data || []);
    } catch (err) {
      console.warn('ดึงข้อมูลจาก API ไม่สำเร็จ (ใช้ข้อมูลจำลองชั่วคราว):', err);
      // ข้อมูลสำรองเผื่อกรณียังไม่ได้เปิด Backend
      setDepartments([
        { id: 1, name: 'ฝ่ายทรัพยากรบุคคล (HR)', description: 'สวัสดิการ กฎระเบียบ และการอบรม', category_count: 2, post_count: 4 },
        { id: 2, name: 'ฝ่ายเทคโนโลยีสารสนเทศ (IT)', description: 'แจ้งเตือนระบบ MA และคู่มือไอที', category_count: 2, post_count: 6 },
        { id: 3, name: 'ฝ่ายความปลอดภัย (Safety)', description: 'มาตรการความปลอดภัยและการซ้อมหนีไฟ', category_count: 1, post_count: 2 },
      ]);
    } finally {
      setLoading(false);
    }
  };

  // ฟังก์ชันบันทึกการสร้าง Folder แผนกใหม่ (ข้อ 1)
  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    if (!nameInput.trim()) return alert('กรุณากรอกชื่อแผนก');

    try {
      const created = await createDepartment(nameInput.trim(), descInput.trim(), userEmail);
      setDepartments([...departments, { ...created, category_count: 0, post_count: 0 }]);
      setIsModalOpen(false);
      setNameInput('');
      setDescInput('');
    } catch (err) {
      alert('สร้างแผนกไม่สำเร็จ: ' + err.message);
    }
  };

  // ฟังก์ชันลบ Folder แผนก
  const handleDeleteDepartment = async (e, deptId, deptName) => {
    e.stopPropagation(); // ห้ามไม่ให้คลิกทะลุไปเปิดแผนก
    if (window.confirm(`คุณแน่ใจว่าต้องการลบ Folder แผนก "${deptName}" ใช่หรือไม่?`)) {
      try {
        await deleteDepartment(deptId);
        setDepartments(departments.filter((d) => d.id !== deptId));
      } catch (err) {
        alert('ลบแผนกไม่สำเร็จ: ' + err.message);
      }
    }
  };

  return (
    <div>
      <Navbar userEmail={userEmail} />

      <main className="container">
        {/* หัวข้อหน้าเว็บ และปุ่ม + สร้าง Folder แผนก (ข้อ 1) */}
        <div className="page-header">
          <div className="page-title">
            <h1>Departments Folder</h1>
            <p>เลือก Folder แผนกเพื่อดูหมวดหมู่และโพสต์ประกาศข่าวสาร</p>
          </div>

          {/* ปุ่ม + สำหรับสร้าง Folder เพื่อแยกหมวดหมู่แต่ละแผนก (ข้อ 1) */}
          <button onClick={() => setIsModalOpen(true)} className="btn btn-primary">
            <span style={{ fontSize: '18px' }}>+</span>
            <span>Create New Department</span>
          </button>
        </div>

        {/* แสดงรายการการ์ด Folder ของแต่ละแผนก (ข้อ 2) */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: '50px 0', color: '#64748b' }}>⏳ กำลังโหลดข้อมูล...</div>
        ) : departments.length === 0 ? (
          <div className="empty-box">
            <div className="empty-icon">📁</div>
            <h3>ยังไม่มี Folder แผนก</h3>
            <p>กดปุ่ม "+ สร้าง Folder แผนก" ด้านบนเพื่อเริ่มสร้างแผนกแรก</p>
            <button onClick={() => setIsModalOpen(true)} className="btn btn-primary">
              + สร้าง Folder แผนก
            </button>
          </div>
        ) : (
          <div className="folder-grid">
            {departments.map((dept) => (
              <div
                key={dept.id}
                className="folder-card"
                onClick={() => navigate(`/department/${dept.id}`)} // คลิกเข้าไปเป็นของแผนกนั้นๆ (ข้อ 2)
              >
                <div>
                  <div className="card-top">
                    <span className="card-folder-icon">📁</span>
                    <button
                      onClick={(e) => handleDeleteDepartment(e, dept.id, dept.name)}
                      className="btn-delete-card"
                      title="ลบแผนกนี้"
                    >
                      🗑️
                    </button>
                  </div>
                  <h3 className="card-title">{dept.name}</h3>
                  <p className="card-desc">{dept.description || 'ไม่มีคำอธิบาย'}</p>
                </div>

                <div className="card-footer">
                  <span>📂 {dept.category_count || 0} หมวดหมู่ | 📢 {dept.post_count || 0} ประกาศ</span>
                  <span style={{ color: '#2563eb', fontWeight: 'bold' }}>เปิดดู →</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal สำหรับกรอกข้อมูลสร้าง Folder แผนกใหม่ */}
        {isModalOpen && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h3>📁 Create New Department</h3>
                <button onClick={() => setIsModalOpen(false)} className="btn-close-modal">✕</button>
              </div>

              <form onSubmit={handleCreateSubmit}>
                <div className="form-group">
                  <label>Department Name <span style={{ color: 'red' }}>*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Human Resources (HR)"
                    className="form-control"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                  />
                </div>

                <div className="form-group">
                  <label>Short Description (if any)</label>
                  <textarea
                    rows={3}
                    placeholder="Specify the purpose or details of the department..."
                    className="form-control"
                    value={descInput}
                    onChange={(e) => setDescInput(e.target.value)}
                  />
                </div>

                <div className="modal-actions">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="btn btn-secondary">
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Department
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default Home;

