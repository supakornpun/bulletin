import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  const navigate = useNavigate();
  const [mockEmail, setMockEmail] = useState('');
  const [showDevLogin, setShowDevLogin] = useState(false);

  useEffect(() => {
    // ถ้ามี Session อยู่แล้ว ให้นำทางเข้าหน้า Home ทันที
    const session = localStorage.getItem('user_session');
    if (session) {
      navigate('/home');
    }
  }, [navigate]);

  // ล็อกอินผ่าน Google Workspace (Google Apps Script)
  const handleGoogleLogin = () => {
    const gasUrl =
      'https://script.google.com/a/macros/minebea.co.th/s/AKfycbzz1nglB-_QvjlQ5Jg4duduoGHiytEnM1rgm1wDGCdKrFBP1v6e0_7-hP9mqsQb4eIu/exec';
    window.location.href = gasUrl;
  };

  // ล็อกอินจำลองสำหรับเด็กใหม่ทดสอบระบบ (Dev Mode)
  const handleDevLogin = (e) => {
    e.preventDefault();
    if (mockEmail.trim()) {
      localStorage.setItem('user_session', mockEmail.trim());
      navigate('/home');
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      backgroundColor: '#f8fafc',
    }}>
      <div style={{
        maxWidth: '400px',
        width: '100%',
        backgroundColor: '#ffffff',
        padding: '36px 28px',
        borderRadius: '16px',
        boxShadow: '0 10px 25px -5px rgba(0,0,0,0.08)',
        border: '1px solid #e2e8f0',
        textAlign: 'center',
      }}>
        <div style={{ fontSize: '48px', marginBottom: '12px' }}>📋</div>
        <h2 style={{ fontSize: '22px', fontWeight: '800', marginBottom: '6px' }}>Bulletin Board</h2>

        {/* ปุ่ม Login ด้วย Google Workspace */}
        <button
          onClick={handleGoogleLogin}
          className="btn btn-primary"
          style={{ width: '100%', justifyContent: 'center', padding: '12px', fontSize: '15px' }}
        >
          🔒 Login with Google Workspace
        </button>

        {/* เมนูเสริมสำหรับเด็กใหม่ใช้ทดสอบระบบโดยไม่ต้องต่อ GAS */}
        <div style={{ marginTop: '24px' }}>
          <button
            type="button"
            onClick={() => setShowDevLogin(!showDevLogin)}
            style={{ background: 'none', border: 'none', color: '#94a3b8', fontSize: '12px', cursor: 'pointer', textDecoration: 'underline' }}
          >
            {/* {showDevLogin ? 'ซ่อนโหมดทดสอบ' : '🛠️ โหมดทดสอบสำหรับนักพัฒนา (Dev Login)'} */}
          </button>

          {showDevLogin && (
            <form onSubmit={handleDevLogin} style={{ marginTop: '14px', textAlign: 'left' }}>
              <label style={{ display: 'block', fontSize: '12px', color: '#64748b', marginBottom: '4px' }}>
                ใส่อีเมลเพื่อจำลอง Session:
              </label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <input
                  type="email"
                  required
                  placeholder="name@minebea.co.th"
                  className="form-control"
                  style={{ fontSize: '13px', padding: '8px 10px' }}
                  value={mockEmail}
                  onChange={(e) => setMockEmail(e.target.value)}
                />
                <button type="submit" className="btn btn-success" style={{ padding: '8px 12px', fontSize: '13px' }}>
                  เข้าสู่ระบบ
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default Login;

