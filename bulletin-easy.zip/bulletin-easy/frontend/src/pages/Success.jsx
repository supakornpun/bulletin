import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Success() {
  const [email, setEmail] = useState('');
  const [countdown, setCountdown] = useState(3);
  const navigate = useNavigate();

  useEffect(() => {
    // 1. ดึงอีเมลที่ GAS หรือระบบส่งกลับมาทาง URL เช่น /success?email=xxx@minebea.co.th
    const params = new URLSearchParams(window.location.search);
    const urlEmail = params.get('email');
    const savedEmail = localStorage.getItem('user_session');

    let currentEmail = '';

    if (urlEmail) {
      currentEmail = urlEmail.trim();
      // บันทึก Session ลงใน Browser
      localStorage.setItem('user_session', currentEmail);
      // ซ่อน param email ออกจาก URL
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (savedEmail) {
      currentEmail = savedEmail.trim();
    } else {
      navigate('/login');
      return;
    }

    setEmail(currentEmail);

    // ระบบนับถอยหลัง 3 วินาที เพื่อนำทางไปหน้า /home อัตโนมัติ
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate('/home');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      backgroundColor: '#f8fafc',
    }}>
      <div style={{
        maxWidth: '440px',
        width: '100%',
        backgroundColor: '#ffffff',
        padding: '36px 30px',
        borderRadius: '16px',
        boxShadow: '0 10px 25px -5px rgba(0,0,0,0.08)',
        border: '1px solid #e2e8f0',
        textAlign: 'center',
      }}>
        {/* ไอคอนเครื่องหมายถูกสีเขียว */}
        <div style={{
          width: '64px',
          height: '64px',
          backgroundColor: '#dcfce7',
          color: '#16a34a',
          fontSize: '32px',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 16px',
        }}>
          ✓
        </div>

        <h2 style={{ fontSize: '22px', fontWeight: '800', marginBottom: '6px' }}>เข้าสู่ระบบสำเร็จ!</h2>
        <p style={{ color: '#64748b', fontSize: '14px', marginBottom: '20px' }}>
          ยินดีต้อนรับเข้าสู่ระบบกระดานประกาศองค์กร
        </p>

        {email && (
          <div style={{
            backgroundColor: '#f1f5f9',
            padding: '12px 16px',
            borderRadius: '8px',
            marginBottom: '24px',
            textAlign: 'left',
            border: '1px solid #e2e8f0',
          }}>
            <span style={{ fontSize: '11px', color: '#64748b', display: 'block' }}>บัญชีผู้ใช้งาน:</span>
            <strong style={{ fontSize: '14px', color: '#0f172a' }}>📧 {email}</strong>
          </div>
        )}

        {/* ปุ่มยืนยันเข้าสู่แอปพลิเคชัน (ข้อ 6) */}
        <button
          onClick={() => navigate('/home')}
          className="btn btn-primary"
          style={{ width: '100%', justifyContent: 'center', padding: '13px', fontSize: '15px' }}
        >
          <span>คลิกเพื่อเข้าสู่แอปพลิเคชัน</span>
          <span>→</span>
        </button>

        <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '14px' }}>
          กำลังนำเข้าสู่หน้าแรกอัตโนมัติใน {countdown} วินาที...
        </p>
      </div>
    </div>
  );
}

export default Success;

