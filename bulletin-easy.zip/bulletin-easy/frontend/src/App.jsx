import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

// นำเข้าหน้าต่างๆ ทั้งหมด
import Login from './pages/Login';
import Success from './pages/Success';
import Home from './pages/Home';
import Department from './pages/Department';
import Category from './pages/Category';

function App() {
  // ตรวจสอบว่าผู้ใช้ล็อกอินอยู่หรือไม่
  const isLoggedIn = !!localStorage.getItem('user_session');

  return (
    <BrowserRouter>
      <Routes>
        {/* หน้าแรก: ถ้ามี Session ไปหน้า /home ถ้าไม่มีไป /login */}
        <Route path="/" element={<Navigate to={isLoggedIn ? '/home' : '/login'} replace />} />

        {/* 1. หน้าล็อกอิน (Google Workspace) */}
        <Route path="/login" element={<Login />} />

        {/* 2. หน้ายืนยันตัวตนสำเร็จ (มีปุ่ม 'คลิกเพื่อเข้าสู่แอปพลิเคชัน') */}
        <Route path="/success" element={<Success />} />

        {/* 3. หน้าแรก: Folder แผนกทั้งหมด + ปุ่มสร้าง Folder (ข้อ 1 & 2) */}
        <Route path="/home" element={<Home />} />

        {/* 4. หน้าในแผนก: Folder หมวดหมู่ย่อย (ข้อ 3) */}
        <Route path="/department/:id" element={<Department />} />

        {/* 5. หน้าห้องประกาศ: รายการโพสต์, แนบรูป, Edit/Delete (ข้อ 3b & 4) */}
        <Route path="/category/:id" element={<Category />} />

        {/* เส้นทางอื่นๆ นอกเหนือจากนี้ ให้กลับไปหน้า /home */}
        <Route path="*" element={<Navigate to="/home" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

