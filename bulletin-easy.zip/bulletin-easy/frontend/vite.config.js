import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174,
    open: true, // เปิดเบราว์เซอร์อัตโนมัติเมื่อสั่ง npm run dev
  },
});

