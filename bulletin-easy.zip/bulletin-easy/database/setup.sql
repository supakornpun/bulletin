-- ==============================================================================
-- 📋 ระบบกระดานประกาศแต่ละแผนก (Bulletin Board System)
-- ไฟล์: database/setup.sql
-- คำอธิบาย: สคริปต์สร้างตารางฐานข้อมูล PostgreSQL สำหรับผู้เริ่มต้น (Junior-friendly)
-- ==============================================================================

-- [ขั้นตอนที่ 1] สร้าง Database (ถ้ายังไม่มี ให้รันคำสั่งด้านล่างนี้ใน pgAdmin หรือ psql)
-- CREATE DATABASE bulletin_db;
-- \c bulletin_db;

-- ------------------------------------------------------------------------------
-- 1. ตารางเก็บ Folder แผนก (Departments)
-- ------------------------------------------------------------------------------
-- ใช้เก็บข้อมูลโฟลเดอร์ของแต่ละแผนก เช่น HR, IT, Production, Safety
CREATE TABLE IF NOT EXISTS departments (
    id SERIAL PRIMARY KEY,                      -- รหัสประจำแผนก (รันเลขอัตโนมัติ 1, 2, 3, ...)
    name VARCHAR(255) NOT NULL,                 -- ชื่อแผนก (จำเป็นต้องระบุ)
    description TEXT,                           -- คำอธิบายสั้นๆ เกี่ยวกับแผนก
    created_by_email VARCHAR(255) NOT NULL,     -- อีเมลของผู้สร้าง Folder แผนกนี้
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP -- วันเวลาที่สร้าง
);

-- ------------------------------------------------------------------------------
-- 2. ตารางเก็บ Folder หมวดหมู่ย่อย (Categories) ภายใต้แผนก
-- ------------------------------------------------------------------------------
-- 1 แผนก สามารถมีได้หลายหมวดหมู่ย่อย เช่น ใน HR มี "สวัสดิการ", "การอบรม"
CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,                      -- รหัสประจำหมวดหมู่ (รันเลขอัตโนมัติ)
    department_id INT NOT NULL,                 -- รหัสแผนกที่เป็นเจ้าของหมวดหมู่นี้
    name VARCHAR(255) NOT NULL,                 -- ชื่อหมวดหมู่ย่อย
    description TEXT,                           -- คำอธิบายหมวดหมู่
    created_by_email VARCHAR(255) NOT NULL,     -- อีเมลของผู้สร้าง Folder หมวดหมู่นี้
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, -- วันเวลาที่สร้าง
    
    -- กำหนดความสัมพันธ์: ถ้า Folder แผนกถูกลบ หมวดหมู่ย่อยข้างในจะถูกลบตามไปด้วย (ON DELETE CASCADE)
    CONSTRAINT fk_department
        FOREIGN KEY (department_id) 
        REFERENCES departments(id) 
        ON DELETE CASCADE
);

-- ------------------------------------------------------------------------------
-- 3. ตารางเก็บโพสต์ประกาศ (Posts) ภายใต้หมวดหมู่
-- ------------------------------------------------------------------------------
-- 1 หมวดหมู่ สามารถมีได้หลายโพสต์ประกาศ สามารถแนบข้อความและรูปภาพได้
CREATE TABLE IF NOT EXISTS posts (
    id SERIAL PRIMARY KEY,                      -- รหัสประจำโพสต์ (รันเลขอัตโนมัติ)
    category_id INT NOT NULL,                   -- รหัสหมวดหมู่ที่เป็นเจ้าของโพสต์นี้
    title VARCHAR(255) NOT NULL,                 -- หัวข้อประกาศ
    content TEXT NOT NULL,                      -- เนื้อหาข้อความประกาศ
    image_url TEXT,                             -- เส้นทางไฟล์รูปภาพ เช่น /uploads/post-12345.png (ใส่ NULL ได้ถ้าไม่มีรูป)
    created_by_email VARCHAR(255) NOT NULL,     -- อีเมลผู้สร้างโพสต์ (**สำคัญมาก: ใช้เช็คสิทธิ์แก้ไข/ลบ**)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, -- วันเวลาที่สร้างโพสต์
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, -- วันเวลาที่แก้ไขโพสต์ล่าสุด
    
    -- กำหนดความสัมพันธ์: ถ้า Folder หมวดหมู่ถูกลบ โพสต์ทั้งหมดในหมวดนั้นจะถูกลบตามไปด้วย
    CONSTRAINT fk_category
        FOREIGN KEY (category_id) 
        REFERENCES categories(id) 
        ON DELETE CASCADE
);

-- ------------------------------------------------------------------------------
-- 4. การสร้าง Indexes เพื่อช่วยให้ระบบค้นหาข้อมูลได้รวดเร็วขึ้น
-- ------------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_categories_dept_id ON categories(department_id);
CREATE INDEX IF NOT EXISTS idx_posts_category_id ON posts(category_id);
CREATE INDEX IF NOT EXISTS idx_posts_created_by ON posts(created_by_email);

-- ------------------------------------------------------------------------------
-- 5. Trigger สำหรับอัปเดตฟิลด์ updated_at อัตโนมัติเมื่อมีการ UPDATE โพสต์
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP; -- ตั้งค่าเวลาใหม่เป็นปัจจุบันทุกครั้งที่มีการ UPDATE
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_posts_updated_at ON posts;
CREATE TRIGGER set_posts_updated_at
BEFORE UPDATE ON posts
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- ==============================================================================
-- 6. ข้อมูลตัวอย่าง (Sample Mock Data) เพื่อให้เด็กใหม่ทดสอบระบบได้ทันที
-- ==============================================================================

-- 6.1 เพิ่มแผนกตัวอย่าง
INSERT INTO departments (name, description, created_by_email) 
VALUES 
    ('ฝ่ายทรัพยากรบุคคล (HR)', 'ประกาศ กฎระเบียบ สวัสดิการพนักงาน และกิจกรรม', 'admin.hr@minebea.co.th'),
    ('ฝ่ายเทคโนโลยีสารสนเทศ (IT)', 'แจ้งเตือนระบบ ประกาศการบำรุงรักษา และคู่มือใช้งาน', 'admin.it@minebea.co.th'),
    ('ฝ่ายความปลอดภัย (Safety & EHS)', 'นโยบายความปลอดภัย มาตรการป้องกัน และการซ้อมหนีไฟ', 'safety@minebea.co.th')
ON CONFLICT DO NOTHING;

-- 6.2 เพิ่มหมวดหมู่ย่อยตัวอย่าง
INSERT INTO categories (department_id, name, description, created_by_email)
VALUES
    (1, 'สวัสดิการและการเบิกจ่าย', 'สิทธิประโยชน์ ประกันสุขภาพกลุ่ม และการเบิกค่ารักษา', 'admin.hr@minebea.co.th'),
    (1, 'การฝึกอบรมและสัมมนา', 'ตารางคอร์สอบรมเพื่อพัฒนาทักษะประจำปี', 'admin.hr@minebea.co.th'),
    (2, 'ประกาศปิดปรับปรุงระบบ MA', 'แจ้งกำหนดการปิดเซิร์ฟเวอร์และระบบเครือข่าย', 'admin.it@minebea.co.th'),
    (2, 'คู่มือและวิธีแก้ปัญหาไอที', 'เอกสาร How-To สำหรับผู้ใช้งานทั่วไป', 'admin.it@minebea.co.th')
ON CONFLICT DO NOTHING;

-- 6.3 เพิ่มโพสต์ตัวอย่าง
INSERT INTO posts (category_id, title, content, image_url, created_by_email)
VALUES
    (1, 'สิทธิประโยชน์ประกันสุขภาพกลุ่ม ประจำปี 2026', 'ขอแจ้งรายละเอียดการใช้สิทธิ์ OPD/IPD สำหรับพนักงานทุกระดับ สามารถยื่นเคลมค่ารักษาผ่านระบบหรือติดต่อ HR ชั้น 2 ในวันทำการ', NULL, 'admin.hr@minebea.co.th'),
    (3, 'แจ้งปิดปรับปรุงระบบเครือข่ายเสาร์นี้ 22:00 - 02:00 น.', 'ฝ่ายไอทีจะทำการอัปเดตระบบ Firewall ประจำเดือน ระบบอินเทอร์เน็ตภายในจะไม่สามารถใช้งานได้ชั่วคราว', NULL, 'admin.it@minebea.co.th')
ON CONFLICT DO NOTHING;

